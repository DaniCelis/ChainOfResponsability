/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chainofresponsabilitycallcenter;

/**
 *
 * @author danic
 */
public class ImagenesDiagnosticas implements IOperador{
    
    private IOperador next;

    @Override
    public IOperador getNext() {
       return next;
    }

    @Override
    public void recibirLLamada(int extension) {
        if(extension == 6){
            System.out.println("Transfiriendo a ImagenesDiagnosticas");
        } else {
            next.recibirLLamada(extension);
        }
    }
    
    @Override
    public void setNext(IOperador operador) {
        next = operador;
    }
    
}
