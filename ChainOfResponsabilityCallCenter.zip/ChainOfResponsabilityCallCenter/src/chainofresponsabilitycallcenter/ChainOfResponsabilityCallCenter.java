/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chainofresponsabilitycallcenter;

import java.util.Scanner;

/**
 *
 * @author danic
 */
public class ChainOfResponsabilityCallCenter {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        System.out.println("Menu de extensiones\n"
                + "1. Optometria\n"
                + "2. Medicina General\n"
                + "3. Pediatria\n"
                + "4. Odontologia\n"
                + "5. Vacunacion\n"
                + "6. Imagenes Diagnosticas\n"
                + "7. Otras Especialidades\n");
              
            Scanner sc = new Scanner(System.in);
            System.out.println("Ingrese la extension a la que desea comunicarse");
            int extension = sc.nextInt();
  
            if(extension >0 && extension < 8){
                Operadora operadora = new Operadora();
                operadora.recibirLLamada(extension);
            }else{
                System.out.println("la extension no existe");
            }
        
    }
    
}
