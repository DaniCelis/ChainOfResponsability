/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chainofresponsabilitycallcenter;

/**
 *
 * @author danic
 */
public class Optometria implements IOperador{

    private IOperador next;

    @Override
    public IOperador getNext() {
       return next;
    }

    @Override
    public void recibirLLamada(int extension) {
        if(extension == 1){
            System.out.println("Transfiriendo a Optometria");
        } else {
            next.recibirLLamada(extension);
        }
    }
    
    @Override
    public void setNext(IOperador operador) {
        next = operador;
    }
}
