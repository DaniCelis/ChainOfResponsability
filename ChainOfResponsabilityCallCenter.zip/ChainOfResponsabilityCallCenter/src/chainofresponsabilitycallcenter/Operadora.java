/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package chainofresponsabilitycallcenter;

/**
 *
 * @author danic
 */
public class Operadora implements IOperador{
    private IOperador next;

    

    public IOperador getNext() {
        return next;
    }

    public void recibirLLamada(int extension) {
        Optometria optometria = new Optometria();
        this.setNext(optometria);
        
        MedicinaGeneral medicinaGeneral = new MedicinaGeneral();
        optometria.setNext(medicinaGeneral);
        
        Pediatria pediatria = new Pediatria();
        medicinaGeneral.setNext(pediatria);
        
        Odontologia odontologia = new Odontologia();
        pediatria.setNext(odontologia);
        
        Vacunacion vacunacion = new Vacunacion();
        odontologia.setNext(vacunacion);
        
        ImagenesDiagnosticas imagenesDiagnosticas = new ImagenesDiagnosticas();
        vacunacion.setNext(imagenesDiagnosticas);
        
        OtrasEspecialidades otrasEspecialidades = new OtrasEspecialidades();
        imagenesDiagnosticas.setNext(otrasEspecialidades);
        
        next.recibirLLamada(extension);
    }
    
    public void setNext(IOperador operador) {
        next = operador;
    }
}
